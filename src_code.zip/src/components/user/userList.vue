<template>
  <div>
    <div class="jumbotron">
      <h1 class="text-center">Users</h1>
    </div>
    <div class="col-md-8">
      <form class="form-inline">
        <div class="form-group">
          <label class="sr-only" for="searchName">Name</label>
          <input type="text" class="form-control" id="searchName" placeholder="Search for a name" v-model="search.name">
        </div>
        <div class="form-group">
          <label class="sr-only" for="searchCompany">Company</label>
          <input type="text" class="form-control" id="searchCompany" placeholder="Search for a company" v-model="search.company">
        </div>
      </form>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
            <tr>
              <th v-for="th in tableHeads">{{th}}</th>
            </tr>
          </thead>
          <tbody>
            <user :user="user" v-for="user in filteredUsers"></user>
          </tbody>
        </table>
      </div>
      
    </div>
    <div class="col-md-4">
      <router-view name="userDetail"></router-view>
    </div>
  </div>
</template>

<script>
  import User from './user.vue'
  import axios from 'axios'

  export default {
    name: 'user-list',
    data () {
      return {
        search: {
          name: '',
          company: ''
        },
        tableHeads: ['#', 'Name', 'Phone', 'City', 'Company'],
        users: []
      }
    },
    components: {
      User
    },
    computed: {
      filteredUsers() {
        const that = this;
        if (this.search.name) {
          return this.users.filter(user => user.name.toLowerCase().indexOf(that.search.name.toLowerCase()) != -1);
        }

        return this.users;
      }
    },
    mounted() {
      const endpoint = "https://jsonplaceholder.typicode.com/users"

      axios.get(endpoint)
        .then(response => this.users = response.data)
        .catch(e => console.log(e))
    }
  }
</script>

<style>
  .router-link-active {
    font-weight: bold;
  }
</style>
