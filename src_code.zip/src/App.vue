<template>
  <div id="app" class="container">
    <user-list></user-list>
  </div>
</template>

<script>
  import UserList from './components/user/userList.vue'
  import {load} from 'vue-google-maps'

  load({
      'key': 'AIzaSyAkMm-OZuHfFAJQhEuETvsOhiNtizJHRzo'
  });

  export default {
    name: 'app',
    data () {
      return {}
    },
    components: {
      UserList
    }
  }
</script>

<style>

</style>
